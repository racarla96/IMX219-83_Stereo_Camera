This directory is specific to the WIFI H&D SPB104 components (\COMPONENTS\WIFI\HD_SPB104). 
