#Build:
$mkdir build
$cd build
$cmake ..
$make

#Run:
$./stereoBM-file ../aloeL.jpg ../aloeR.jpg

