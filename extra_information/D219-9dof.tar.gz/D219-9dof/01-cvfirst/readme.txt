#Build:
$mkdir build
$cd build
$cmake ..
$make

#Run:
$./cvfirst ./yui.jpg
