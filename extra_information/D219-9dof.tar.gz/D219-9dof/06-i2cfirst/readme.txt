#Build:
$make

#Run:
$./i2cfirst

