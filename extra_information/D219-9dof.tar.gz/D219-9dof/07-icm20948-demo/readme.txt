#Build:
$make

#Run:
$./ICM20948_Demo

