#运行环境：
硬     件 : Jetson Nano Developer Kit
SD镜像 : Jetson Nano Developer Kit SD Card Image @2019/12/17  built with JetPack 4.3

#示例程序说明
01-cvfirst : 读一个图片文件，并显示；
02-camera-display : 显示一个摄像头画面;
03-double-camera-display : 显示两个摄像头画面;
04-stereoBM : 从文件读取两张图，实现生成视差图并显示；
05-stereoBM-camera : 显示两个摄像头画面, 及对应的视察图；
06-i2cfirst : 读取一个i2c寄存器值；(读取到0xea则能说明icm20948的ic通信正常)
07-icm20948-demo :读取icm20948传感器值
----------------------------------------------------------------
version : 0.1@2020/01/30

