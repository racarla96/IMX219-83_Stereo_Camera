#Build:
$mkdir build
$cd build
$cmake ..
$make

#Run:
$./stereoBM-camera

