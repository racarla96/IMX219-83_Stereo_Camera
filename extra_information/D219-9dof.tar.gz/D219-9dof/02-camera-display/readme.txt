#Build:$mkdir build $cd build$cmake ..$make#Run:$./camera-display
