#Build:
$mkdir build
$cd build
$cmake ..
$make

#Run:
$./double-camera-display

