#Build:
$mkdir build
$cd build
$cmake ..
$make

#Run:
$./videocapture_camera




