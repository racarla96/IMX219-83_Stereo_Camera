#Build:
$mkdir build
$cd build
$cmake ..
$make

#Run:
$./imagecapture_camera



