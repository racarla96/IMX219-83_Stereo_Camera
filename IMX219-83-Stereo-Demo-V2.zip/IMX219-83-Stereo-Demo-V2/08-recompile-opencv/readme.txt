#DES
Jetson Nano默认安装的opencv未包含Cuda库 需重新编译安装
用户也可根据需要自行选择重新安装的Opencv版本

#Run:
$./install_opencv4.1.1_Jetson.sh

