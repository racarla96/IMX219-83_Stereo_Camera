#include "ICM_20948.hpp"

ICM_20948::ICM_20948(int bus, uint8_t address) : i2cpp::Device(bus, address)
{
}

uint16_t ICM_20948::read_register(uint8_t reg)
{
	uint8_t buffer[3] = { reg, 0x00, 0x00 };
	this->read_i2c(buffer, 3);
	return uint16_t((buffer[1] << 8) | buffer[0]);
}

bool PCA9555::write_register(uint_fast8_t reg, uint_fast16_t data)
{
	uint_fast8_t buffer[3] = { reg, uint_fast8_t(data & 0xff), uint_fast8_t(data >> 8) };
	return this->write_i2c(buffer, 3) == 3;
}