#include <iostream>
#include <i2cpp/i2cpp.hpp>
#include "ICM_20948.hpp"
#include "ArduinoLinuxLayer.h"

//using namespace i2cpp;
using namespace std;

int main() {

	ICM_20948 icm_20948(1, 0x68);

	cout << icm_20948.read_register(0x2D) << "\n";
	delay(100);
	cout << icm_20948.read_register(0x2D) << "\n";
	delay(100);
	cout << icm_20948.read_register(0x2D) << "\n";
	delay(100);
	cout << icm_20948.read_register(0x2D) << "\n";
	delay(100);
	cout << icm_20948.read_register(0x2D) << "\n";
	delay(100);
	cout << icm_20948.read_register(0x2D) << "\n";
	return 0;
}

