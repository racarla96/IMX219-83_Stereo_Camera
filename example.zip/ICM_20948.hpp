/**
 * @file ads1115.hpp
 * @author Scott Fasone
 */

#ifndef ICM_20948_HPP
#define ICM_20948_HPP

#include <i2cpp/i2cpp.hpp>
#include <i2cpp/device.hpp>

/**
 * ICM_20948 : XXX
 * Reference Documentation: XXX
 *
 * This device implementation is currently a work-in-progress
 * @ingroup Devices
 */
class ICM_20948 : public i2cpp::Device
{
public:
	ICM_20948(int bus, uint8_t address);
	uint16_t read_register(uint8_t reg);
};


#endif //ICM_20948_HPP