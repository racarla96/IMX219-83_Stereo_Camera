#include <unistd.h>

#define F(string_literal) string_literal

void delay(unsigned long ms);
